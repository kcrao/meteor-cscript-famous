(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var famous;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mjn:famous'] = {
  famous: famous
};

})();

//# sourceMappingURL=mjn_famous.js.map
